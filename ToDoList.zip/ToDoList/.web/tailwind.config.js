
import plugin1 from "@tailwindcss/typography";
export default {
    content: ["./app/**/*.{js,ts,jsx,tsx}", "./utils/**/*.{js,ts,jsx,tsx}"],
theme: {},    plugins: [
                plugin1,
    ]
};