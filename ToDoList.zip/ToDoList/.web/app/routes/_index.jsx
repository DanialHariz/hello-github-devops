

import { Fragment, useCallback, useContext, useEffect } from "react"
import { Box as RadixThemesBox, Button as RadixThemesButton, Flex as RadixThemesFlex, Heading as RadixThemesHeading, Text as RadixThemesText, TextArea as RadixThemesTextArea, TextField as RadixThemesTextField } from "@radix-ui/themes"
import DebounceInput from "react-debounce-input"
import { EventLoopContext, StateContexts } from "$/utils/context"
import { Event, isNotNullOrUndefined, isTrue } from "$/utils/state"
import { jsx } from "@emotion/react"



function Flex_71c9e12a264c6e88781e8ed8af3253ca () {
  
  const reflex___state____state__to_do_list____to_do_list____state = useContext(StateContexts.reflex___state____state__to_do_list____to_do_list____state)
  const [addEvents, connectErrors] = useContext(EventLoopContext);





  
  return (
    jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"column",gap:"3"},
jsx(
RadixThemesHeading,
{},
"\ud83d\udccbTodo App"
,),jsx(Debounceinput_8977b4f478e0c685e66d2a8361a4b0d2,{},)
,jsx(Debounceinput_667b2a7d8eb743efadd10a2be62854c0,{},)
,jsx(Debounceinput_5ac65c1db4fde24f7c9c65e926a825ed,{},)
,jsx(Button_bfda3338d318c2966a6b9df1446b807b,{},)
,reflex___state____state__to_do_list____to_do_list____state.tasks_rx_state_.map((task_rx_state_,index_4732a632fc1f955c)=>(jsx(
RadixThemesBox,
{css:({ ["border"] : "1px solid #ccc", ["padding"] : "1em", ["marginBottom"] : "1em", ["opacity"] : ((task_rx_state_["status"] === "complete") ? "0.5" : "1.0") }),key:index_4732a632fc1f955c},
jsx(
RadixThemesText,
{as:"p",css:({ ["fontWeight"] : "bold" })},
task_rx_state_["title"]
,),jsx(
RadixThemesText,
{as:"p"},
task_rx_state_["description"]
,),jsx(
RadixThemesText,
{as:"p"},
("Due: "+task_rx_state_["due_date"])
,),jsx(
Fragment,
{},
((task_rx_state_["status"] === "complete") ? (jsx(
Fragment,
{},
jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "green" })},
"\u2705 Complete"
,),)) : (jsx(
Fragment,
{},
(((task_rx_state_["due_date"] < "2025-07-03") && !((task_rx_state_["status"] === "complete"))) ? (jsx(
Fragment,
{},
jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "red" })},
"\u26a0 Overdue"
,),)) : (jsx(
Fragment,
{},
jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "orange" })},
"\u23f3 Pending"
,),))),))),),jsx(
RadixThemesButton,
{onClick:((_e) => (addEvents([(Event("reflex___state____state.to_do_list____to_do_list____state.edit_task", ({ ["task_id"] : task_rx_state_["id"] }), ({  })))], [_e], ({  }))))},
"Edit"
,),jsx(
RadixThemesButton,
{onClick:((_e) => (addEvents([(Event("reflex___state____state.to_do_list____to_do_list____state.delete_task", ({ ["task_id"] : task_rx_state_["id"] }), ({  })))], [_e], ({  }))))},
"Delete"
,),jsx(
RadixThemesButton,
{onClick:((_e) => (addEvents([(Event("reflex___state____state.to_do_list____to_do_list____state.toggle_complete", ({ ["task_id"] : task_rx_state_["id"] }), ({  })))], [_e], ({  }))))},
"Toggle Complete"
,),))),)
  )
}

function Debounceinput_667b2a7d8eb743efadd10a2be62854c0 () {
  
  const reflex___state____state__to_do_list____to_do_list____state = useContext(StateContexts.reflex___state____state__to_do_list____to_do_list____state)
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_change_a12e769298b7b711384ec6b8d1ffc911 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.to_do_list____to_do_list____state.set_description", ({ ["value"] : _e["target"]["value"] }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(DebounceInput,{debounceTimeout:300,element:RadixThemesTextArea,onChange:on_change_a12e769298b7b711384ec6b8d1ffc911,placeholder:"Description",value:reflex___state____state__to_do_list____to_do_list____state.description_rx_state_},)

  )
}

function Button_bfda3338d318c2966a6b9df1446b807b () {
  
  const reflex___state____state__to_do_list____to_do_list____state = useContext(StateContexts.reflex___state____state__to_do_list____to_do_list____state)
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_dc894ac3e2f4c2863d8a8e49c2a99cd1 = useCallback(((_e) => (addEvents([(isTrue(reflex___state____state__to_do_list____to_do_list____state.editing_id_rx_state_) ? (Event("reflex___state____state.to_do_list____to_do_list____state.save_task", ({  }), ({  }))) : (Event("reflex___state____state.to_do_list____to_do_list____state.add_task", ({  }), ({  }))))], [_e], ({  })))), [addEvents, Event, reflex___state____state__to_do_list____to_do_list____state])



  
  return (
    jsx(
RadixThemesButton,
{onClick:on_click_dc894ac3e2f4c2863d8a8e49c2a99cd1},
(isTrue(reflex___state____state__to_do_list____to_do_list____state.editing_id_rx_state_) ? "Save" : "Add Task")
,)
  )
}

function Debounceinput_8977b4f478e0c685e66d2a8361a4b0d2 () {
  
  const reflex___state____state__to_do_list____to_do_list____state = useContext(StateContexts.reflex___state____state__to_do_list____to_do_list____state)
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_change_e259fd642e4b17b5d618b88a94f61010 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.to_do_list____to_do_list____state.set_title", ({ ["value"] : _e["target"]["value"] }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(DebounceInput,{debounceTimeout:300,element:RadixThemesTextField.Root,onChange:on_change_e259fd642e4b17b5d618b88a94f61010,placeholder:"Title",value:(isNotNullOrUndefined(reflex___state____state__to_do_list____to_do_list____state.title_rx_state_) ? reflex___state____state__to_do_list____to_do_list____state.title_rx_state_ : "")},)

  )
}

function Debounceinput_5ac65c1db4fde24f7c9c65e926a825ed () {
  
  const reflex___state____state__to_do_list____to_do_list____state = useContext(StateContexts.reflex___state____state__to_do_list____to_do_list____state)
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_change_00eb17af8919892bfaa53f02fe679634 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.to_do_list____to_do_list____state.set_due_date", ({ ["value"] : _e["target"]["value"] }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(DebounceInput,{css:({ ["type"] : "date" }),debounceTimeout:300,element:RadixThemesTextField.Root,onChange:on_change_00eb17af8919892bfaa53f02fe679634,placeholder:"YYYY-MM-DD",value:(isNotNullOrUndefined(reflex___state____state__to_do_list____to_do_list____state.due_date_rx_state_) ? reflex___state____state__to_do_list____to_do_list____state.due_date_rx_state_ : "")},)

  )
}

export default function Component() {
    




  return (
    jsx(
Fragment,
{},
jsx(Flex_71c9e12a264c6e88781e8ed8af3253ca,{},)
,jsx(
"title",
{},
"Todolist | Index"
,),jsx("meta",{content:"favicon.ico",property:"og:image"},)
,)
  )
}
